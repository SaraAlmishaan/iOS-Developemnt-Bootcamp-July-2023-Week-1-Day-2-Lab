import UIKit


// Task 1: Variable Practice

var score = 1
score += 10
print(score)

// Task 2: Control Flow

if score > 9 {
    print("Pass")
}else{
    print("Fail")
}

// Task 3: Loop Practice

var names = ["sara","nawaf","omar","amal","wjdan"]

for i in names {
    print(i)
}

// Task 4: Working with Dictionaries

var fruit = ["banana":4, "orange":6, "mango":2, "apple":5, "grapes":1]

for i in fruit {
    print(i)
}

// Task 5: String Interpolation

let name = "Sara Almishaan"

print("Welcome \(name)")

